package com.example.devise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeviseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeviseApplication.class, args);
	}

}
